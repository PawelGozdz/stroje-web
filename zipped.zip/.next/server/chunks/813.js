"use strict";
exports.id = 813;
exports.ids = [813];
exports.modules = {

/***/ 9813:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* reexport */ Theme)
});

// EXTERNAL MODULE: external "@mui/material/styles"
var styles_ = __webpack_require__(8035);
// EXTERNAL MODULE: external "@mui/material/colors"
var colors_ = __webpack_require__(517);
;// CONCATENATED MODULE: ./theme/Theme.js


const ongPrimary = '#2196F3';
const ongSecondary = '#EC407A';
const black = '#000000';
const white = '#ffffff';
const mainBlack = '#424242';
const defaultTheme = (0,styles_.createTheme)();
/* harmony default export */ const Theme = ((0,styles_.createTheme)({
  props: {
    MuiLink: {
      underline: 'always'
    }
  },
  overrides: {
    MuiCssBaseline: {
      '@global': {
        a: {
          textDecoration: 'none',
          color: colors_.grey[800]
        }
      }
    }
  },
  palette: {
    common: {
      primary: {
        main: `${ongPrimary}`
      },
      secondary: {
        main: `${ongSecondary}`
      },
      bg: {
        blue: colors_.blue,
        yellow: colors_.yellow,
        green: colors_.green,
        red: colors_.red,
        orange: colors_.orange
      }
    }
  },
  typography: {
    tab: {
      color: 'red'
    },
    'h1': {
      color: ongPrimary,
      [defaultTheme.breakpoints.down('sm')]: {
        fontSize: '4.5rem'
      }
    },
    'h2': {
      [defaultTheme.breakpoints.down('sm')]: {
        fontSize: '3rem'
      }
    },
    'h3': {
      [defaultTheme.breakpoints.down('sm')]: {
        fontSize: '2.4rem'
      }
    },
    'h4': {
      [defaultTheme.breakpoints.down('sm')]: {
        fontSize: '2rem'
      }
    },
    'h5': {
      [defaultTheme.breakpoints.down('sm')]: {
        fontSize: '1.3rem'
      }
    }
  },
  breakpoints: {
    values: {
      xs: 0,
      sm: 600,
      md: 860,
      lg: 1200,
      xl: 1720
    }
  },
  customButtons: {
    primary: formatButtons(colors_.lightBlue[500]),
    secondary: formatButtons(ongSecondary),
    white: formatButtons(colors_.grey[50])
  },
  sections: {
    section: {
      [defaultTheme.breakpoints.down('sm')]: {
        padding: defaultTheme.spacing(2, 0)
      },
      padding: defaultTheme.spacing(4, 0)
    },
    header: {
      color: defaultTheme.palette.grey[600],
      margin: defaultTheme.spacing(2, 0)
    }
  },
  container: {
    height: '100%',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    [defaultTheme.breakpoints.up('md')]: {
      flexDirection: 'row'
    }
  }
}));

function formatButtons(backgroundColor) {
  return {
    backgroundColor,
    textDecoration: 'none',
    padding: '.5rem',
    borderRadius: '2px',
    boxShadow: defaultTheme.shadows[4],
    transition: defaultTheme.transitions.create('transform', {
      duration: defaultTheme.transitions.duration.shortest
    }),
    '& > a': {
      color: white
    },
    '&:hover': {
      boxShadow: defaultTheme.shadows[6],
      transform: 'translateY(-1px)'
    },
    '&:active': {
      transform: 'translateY(0px)'
    },
    [defaultTheme.breakpoints.up('sm')]: {
      fontSize: '1.2rem'
    }
  };
}
;// CONCATENATED MODULE: ./theme/index.js


/***/ })

};
;