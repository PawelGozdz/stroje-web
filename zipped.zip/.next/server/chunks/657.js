exports.id = 657;
exports.ids = [657];
exports.modules = {

/***/ 312:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* reexport */ BasicLayout)
});

// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(7949);
// EXTERNAL MODULE: external "@mui/styles"
var styles_ = __webpack_require__(6806);
// EXTERNAL MODULE: external "lodash"
var external_lodash_ = __webpack_require__(3804);
// EXTERNAL MODULE: ./context/StateContext.js + 1 modules
var StateContext = __webpack_require__(5692);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/Footer/Address/Address.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







function Address({
  address
}) {
  const classes = useStyles();
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
      component: "h4",
      children: address.title
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
      component: "ul",
      className: classes.list,
      children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
        children: external_lodash_.map(address.values.phones)
      }), /*#__PURE__*/jsx_runtime_.jsx("li", {
        children: address.values.email
      }), /*#__PURE__*/jsx_runtime_.jsx("li", {
        children: address.values.address.city
      }), /*#__PURE__*/jsx_runtime_.jsx("li", {
        children: address.values.address.street
      }), /*#__PURE__*/jsx_runtime_.jsx("li", {
        children: address.values.address.postCode
      })]
    })]
  });
}
const useStyles = (0,styles_.makeStyles)(theme => ({
  section: _objectSpread(_objectSpread({}, theme.sections.section), {}, {
    alignItems: 'center'
  }),
  container: _objectSpread({}, theme.container)
}));
;// CONCATENATED MODULE: ./components/Footer/Address/index.js

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./components/Footer/Categories/FooterCategoriesList.js
function FooterCategoriesList_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function FooterCategoriesList_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { FooterCategoriesList_ownKeys(Object(source), true).forEach(function (key) { FooterCategoriesList_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { FooterCategoriesList_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function FooterCategoriesList_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }








function FooterCategoriesList({
  categories
}) {
  const classes = FooterCategoriesList_useStyles();
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
      component: "h4",
      children: categories.title
    }), /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
      component: "ul",
      className: classes.list,
      children: external_lodash_.size(categories.values) > 0 && external_lodash_.map(categories.values, item => /*#__PURE__*/jsx_runtime_.jsx(Categoria, {
        item: item
      }, item.kategoria))
    })]
  });
}

const Categoria = ({
  item,
  query
}) => {
  const classes = FooterCategoriesList_useStyles();
  return /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
    component: "li",
    children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
      href: `/kategoria/${item.url}`,
      passHref: true,
      children: /*#__PURE__*/jsx_runtime_.jsx("a", {
        className: classes.link,
        children: item.kategoria
      })
    })
  });
};

const FooterCategoriesList_useStyles = (0,styles_.makeStyles)(theme => ({
  container: FooterCategoriesList_objectSpread({}, theme.container),
  footer: {
    minHeight: '4rem;',
    textAlign: 'center',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 'auto',
    marginBottom: theme.spacing(0)
  },
  link: {
    textDecoration: 'underline'
  }
}));
;// CONCATENATED MODULE: ./components/Footer/Categories/index.js

;// CONCATENATED MODULE: ./components/Footer/Partners/Partners.js
function Partners_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function Partners_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Partners_ownKeys(Object(source), true).forEach(function (key) { Partners_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Partners_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Partners_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }








function Partners({
  partners
}) {
  const classes = Partners_useStyles();
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
      component: "h4",
      children: partners.title
    }), /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
      component: "ul",
      className: classes.list,
      children: external_lodash_.map(partners.values, p => /*#__PURE__*/jsx_runtime_.jsx(Partner, {
        partner: p
      }, p.url))
    })]
  });
}

const Partner = ({
  partner
}) => {
  const classes = Partners_useStyles();
  return /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
    component: "li",
    children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
      href: `${partner.url}`,
      passHref: true,
      children: /*#__PURE__*/jsx_runtime_.jsx("a", {
        className: classes.link,
        target: "_blank",
        children: partner.title
      })
    })
  });
};

const Partners_useStyles = (0,styles_.makeStyles)(theme => ({
  section: Partners_objectSpread(Partners_objectSpread({}, theme.sections.section), {}, {
    alignItems: 'center'
  }),
  container: Partners_objectSpread({}, theme.container),
  link: {
    textDecoration: 'underline'
  }
}));
;// CONCATENATED MODULE: ./components/Footer/Partners/index.js

;// CONCATENATED MODULE: ./components/Footer/Footer.js
function Footer_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function Footer_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Footer_ownKeys(Object(source), true).forEach(function (key) { Footer_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Footer_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Footer_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }










function Footer() {
  const classes = Footer_useStyles();
  const footerMenu = [{
    title: 'Kategorie',
    values: (0,StateContext/* useAppContext */.b)().categories
  }, {
    title: 'Kontakt',
    values: {
      phones: ['788 479 789'],
      email: 'agencja-reklamowa-impuls@wp.pl',
      address: {
        street: 'ul. Owocowa 3',
        postCode: '27-200',
        city: 'Starachowice'
      }
    }
  }, {
    title: 'Partnerzy',
    values: [{
      title: 'Agencja Reklamowa Impuls',
      url: 'http://arimpuls.pl/'
    }, {
      title: 'Opieka Nad Grobami',
      url: 'http://opieka-nad-grobami.com/'
    }]
  }];
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Container, {
    maxWidth: "xl",
    className: classes.container,
    children: [/*#__PURE__*/jsx_runtime_.jsx(FooterCategoriesList, {
      categories: footerMenu[0]
    }), /*#__PURE__*/jsx_runtime_.jsx(material_.Divider, {
      className: classes.divider,
      orientation: "vertical",
      variant: "middle",
      flexItem: true
    }), /*#__PURE__*/jsx_runtime_.jsx(Address, {
      address: footerMenu[1]
    }), /*#__PURE__*/jsx_runtime_.jsx(material_.Divider, {
      className: classes.divider,
      orientation: "vertical",
      variant: "middle",
      flexItem: true
    }), /*#__PURE__*/jsx_runtime_.jsx(Partners, {
      partners: footerMenu[2]
    })]
  });
}
const Footer_useStyles = (0,styles_.makeStyles)(theme => ({
  container: Footer_objectSpread(Footer_objectSpread({}, theme.container), {}, {
    paddingTop: `${theme.spacing(3)}`,
    paddingBottom: `${theme.spacing(3)}`,
    background: `${theme.palette.common.primary.main} !important`,
    color: theme.palette.grey[50],
    justifyContent: 'center',
    alignItems: 'center',
    [theme.breakpoints.up('md')]: {
      justifyContent: 'flex-start',
      alignItems: 'baseline'
    },
    '& h4': {
      fontSize: '1.4rem',
      textAlign: 'center',
      [theme.breakpoints.up('md')]: {
        textAlign: 'left',
        fontSize: '1.6rem'
      }
    },
    '& ul': {
      marginLeft: 0,
      paddingLeft: 0,
      listStyle: 'none',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      [theme.breakpoints.up('md')]: {
        alignItems: 'flex-start'
      },
      '& > *': {
        display: 'flex',
        justifyContent: 'center',
        [theme.breakpoints.up('sm')]: {
          justifyContent: 'flex-start'
        }
      },
      '&:not(:last-child)': {
        marginRight: theme.spacing(4)
      }
    }
  }),
  divider: {
    display: 'none',
    background: `${theme.palette.grey[50]} !important`,
    width: '1px',
    marginLeft: theme.spacing(4),
    marginRight: theme.spacing(4),
    [theme.breakpoints.up('sm')]: {
      display: 'flex'
    }
  }
}));
;// CONCATENATED MODULE: ./components/Footer/index.js

// EXTERNAL MODULE: external "@mui/icons-material/Search"
var Search_ = __webpack_require__(1893);
;// CONCATENATED MODULE: ./components/Header/TopBar/TopBar.js
function TopBar_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function TopBar_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { TopBar_ownKeys(Object(source), true).forEach(function (key) { TopBar_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { TopBar_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function TopBar_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }








function TopBar({
  menu
}) {
  const classes = TopBar_useStyles();

  const indexPageItem = external_lodash_.head(external_lodash_.filter(menu, {
    url: ''
  }));

  const searchPageItem = external_lodash_.head(external_lodash_.filter(menu, {
    url: 'wyszukaj'
  }));

  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/jsx_runtime_.jsx(Logo, {
      indexPage: indexPageItem
    })
  });
}

function Logo({
  indexPage
}) {
  const classes = TopBar_useStyles();
  return /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
    href: `/${indexPage.url}`,
    passHref: true,
    children: /*#__PURE__*/jsx_runtime_.jsx("a", {
      children: /*#__PURE__*/jsx_runtime_.jsx("img", {
        src: "/LOGO.svg",
        alt: "Site Logo",
        title: "Wypo\u017Cyczalnia stroj\xF3w karnawa\u0142owych",
        className: classes.logo
      })
    })
  });
}

const TopBar_useStyles = (0,styles_.makeStyles)(theme => ({
  searchLink: TopBar_objectSpread(TopBar_objectSpread({}, theme.customButtons.primary), {}, {
    marginLeft: theme.spacing(5),
    display: 'none',
    [theme.breakpoints.up('sm')]: {
      display: 'flex',
      marginRight: 'auto'
    }
  }),
  searchIcon: {
    marginRight: theme.spacing(1)
  },
  logo: {
    width: '5.4rem',
    height: 'auto',
    [theme.breakpoints.up('sm')]: {
      width: '6.8rem'
    },
    [theme.breakpoints.up('lg')]: {
      width: '7.2rem'
    } // boxShadow: theme.shadows[3, 6]

  },
  centreIcon: {
    display: 'flex',
    alignItems: 'center',
    alignContent: 'center'
  }
}));
;// CONCATENATED MODULE: ./components/Header/TopBar/index.js

// EXTERNAL MODULE: external "@mui/material/SwipeableDrawer"
var SwipeableDrawer_ = __webpack_require__(1873);
var SwipeableDrawer_default = /*#__PURE__*/__webpack_require__.n(SwipeableDrawer_);
// EXTERNAL MODULE: external "@mui/material/Button"
var Button_ = __webpack_require__(1874);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button_);
// EXTERNAL MODULE: external "@mui/material/List"
var List_ = __webpack_require__(8656);
var List_default = /*#__PURE__*/__webpack_require__.n(List_);
// EXTERNAL MODULE: external "@mui/material/Divider"
var Divider_ = __webpack_require__(818);
var Divider_default = /*#__PURE__*/__webpack_require__.n(Divider_);
// EXTERNAL MODULE: external "@mui/icons-material/PlaylistAddCheck"
var PlaylistAddCheck_ = __webpack_require__(2971);
var PlaylistAddCheck_default = /*#__PURE__*/__webpack_require__.n(PlaylistAddCheck_);
// EXTERNAL MODULE: external "@mui/material/ListItem"
var ListItem_ = __webpack_require__(1270);
var ListItem_default = /*#__PURE__*/__webpack_require__.n(ListItem_);
// EXTERNAL MODULE: external "@mui/material/ListItemIcon"
var ListItemIcon_ = __webpack_require__(5257);
var ListItemIcon_default = /*#__PURE__*/__webpack_require__.n(ListItemIcon_);
// EXTERNAL MODULE: external "@mui/material/ListItemText"
var ListItemText_ = __webpack_require__(7533);
var ListItemText_default = /*#__PURE__*/__webpack_require__.n(ListItemText_);
// EXTERNAL MODULE: external "@mui/icons-material/MoveToInbox"
var MoveToInbox_ = __webpack_require__(8613);
var MoveToInbox_default = /*#__PURE__*/__webpack_require__.n(MoveToInbox_);
// EXTERNAL MODULE: external "@mui/icons-material/Menu"
var Menu_ = __webpack_require__(3903);
var Menu_default = /*#__PURE__*/__webpack_require__.n(Menu_);
;// CONCATENATED MODULE: ./components/Header/Menu/Menu.js
function Menu_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function Menu_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Menu_ownKeys(Object(source), true).forEach(function (key) { Menu_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Menu_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Menu_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

















function Menu({
  menu
}) {
  const theme = (0,styles_.useTheme)();
  const classes = Menu_useStyles();
  const [state, setState] = external_react_default().useState({
    right: false
  });
  const isMobile = (0,material_.useMediaQuery)(theme.breakpoints.down('md'));

  const toggleDrawer = (anchor, open) => event => {
    if (event && event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) {
      return;
    }

    setState(Menu_objectSpread(Menu_objectSpread({}, state), {}, {
      [anchor]: open
    }));
  };

  const anchor = 'right';
  return /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(MenuDrawer, {
      anchor: anchor,
      classes: classes,
      toggleDrawer: toggleDrawer,
      state: state,
      children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
        className: classes.listHeader,
        variant: "h6",
        children: "Strony"
      }), /*#__PURE__*/jsx_runtime_.jsx(MenuList, {
        menu: menu
      }), /*#__PURE__*/jsx_runtime_.jsx((Divider_default()), {}), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
        className: classes.listHeader,
        variant: "h6",
        children: "Partnerzy"
      }), /*#__PURE__*/jsx_runtime_.jsx(PartnersList, {})]
    })
  });
}

const MenuDrawer = ({
  children,
  classes,
  anchor,
  toggleDrawer,
  state
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
    component: "div",
    className: classes.root,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)((external_react_default()).Fragment, {
      children: [/*#__PURE__*/jsx_runtime_.jsx((Button_default()), {
        onClick: toggleDrawer(anchor, true),
        children: /*#__PURE__*/jsx_runtime_.jsx((Menu_default()), {})
      }), /*#__PURE__*/jsx_runtime_.jsx((SwipeableDrawer_default()), {
        anchor: anchor,
        open: state[anchor],
        onClose: toggleDrawer(anchor, false),
        onOpen: toggleDrawer(anchor, true),
        children: children
      })]
    }, anchor)
  });
};

const MenuList = ({
  noIcon = false,
  classes,
  menu
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx((List_default()), {
    className: classes ? classes.servicesListTopBar : '',
    children: menu.map(item => /*#__PURE__*/jsx_runtime_.jsx(MenuItem, {
      noIcon: noIcon,
      item: item
    }, item.url))
  });
};

const MenuItem = ({
  item,
  noIcon
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
    href: `/${item.url}`,
    passHref: true,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)((ListItem_default()), {
      button: true,
      component: "a",
      children: [!noIcon ? /*#__PURE__*/(0,jsx_runtime_.jsxs)((ListItemIcon_default()), {
        children: [/*#__PURE__*/jsx_runtime_.jsx((PlaylistAddCheck_default()), {}), " "]
      }) : '', /*#__PURE__*/jsx_runtime_.jsx((ListItemText_default()), {
        children: item.item
      })]
    })
  });
};

const PartnersList = () => {
  return /*#__PURE__*/jsx_runtime_.jsx((List_default()), {
    children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
      href: "http://arimpuls.pl/",
      passHref: true,
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)((ListItem_default()), {
        button: true,
        component: "a",
        target: "_blank",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)((ListItemIcon_default()), {
          children: [/*#__PURE__*/jsx_runtime_.jsx((MoveToInbox_default()), {}), " "]
        }), /*#__PURE__*/jsx_runtime_.jsx((ListItemText_default()), {
          children: "Agencja Impuls"
        })]
      })
    })
  });
};

const Menu_useStyles = (0,styles_.makeStyles)(theme => ({
  list: {
    width: '400px',
    background: 'tomato'
  },
  root: {
    [theme.breakpoints.down('sm')]: {
      marginLeft: 'auto'
    }
  },
  fullList: {
    width: 'auto',
    marginTop: theme.spacing(3),
    fontWeight: 'bold'
  },
  authList: {},
  userDetails: {
    marginLeft: 'auto',
    textAlign: 'right',
    [theme.breakpoints.down('xs')]: {
      fontSize: '.85rem'
    }
  },
  userStyles: {
    display: 'inline-block',
    fontWeight: 'bold',
    textAlign: 'right'
  },
  servicesListTopBar: {
    display: 'flex',
    flexDirection: 'row',
    marginLeft: theme.spacing(3)
  },
  listHeader: {
    marginLeft: theme.spacing(1)
  }
}));
;// CONCATENATED MODULE: ./components/Header/Menu/index.js

// EXTERNAL MODULE: ./utils/constants.js
var constants = __webpack_require__(9316);
;// CONCATENATED MODULE: ./components/Header/Header.js








function Header() {
  const classes = Header_useStyles();
  return /*#__PURE__*/jsx_runtime_.jsx(material_.Container, {
    maxWidth: "xl",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Toolbar, {
      className: classes.toolbar,
      children: [/*#__PURE__*/jsx_runtime_.jsx(TopBar, {
        menu: constants/* menu */.GI
      }), /*#__PURE__*/jsx_runtime_.jsx(Menu, {
        menu: constants/* menu */.GI
      })]
    })
  });
}
const Header_useStyles = (0,styles_.makeStyles)(theme => ({
  toolbar: {
    // minHeight: 100,
    display: "flex",
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center !important",
    padding: theme.spacing(1),
    paddingLeft: 0,
    paddingRight: 0
  }
}));
;// CONCATENATED MODULE: ./components/Header/index.js

;// CONCATENATED MODULE: ./layouts/BasicLayout/BasicLayout.js






function BasicLayout({
  children
}) {
  const classes = BasicLayout_useStyles();
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
    className: classes.app,
    children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
      component: "header",
      className: classes.topBar,
      children: /*#__PURE__*/jsx_runtime_.jsx(Header, {})
    }), /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
      component: "main",
      children: children
    }), /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
      component: "footer",
      className: classes.footer,
      children: /*#__PURE__*/jsx_runtime_.jsx(Footer, {})
    })]
  });
}
const BasicLayout_useStyles = (0,styles_.makeStyles)(theme => ({
  app: {
    minHeight: '100vh',
    display: 'flex',
    flexDirection: 'column',
    boxSizing: 'content-box'
  },
  topBar: {
    width: '100%',
    boxShadow: theme.shadows[4]
  },
  footer: {
    width: '100%',
    boxShadow: theme.shadows[4],
    marginTop: 'auto'
  },
  main: {
    flex: 1,
    maxWidth: '100%'
  }
}));
;// CONCATENATED MODULE: ./layouts/BasicLayout/index.js


/***/ }),

/***/ 2431:
/***/ (() => {

/* (ignored) */

/***/ })

};
;