"use strict";
exports.id = 930;
exports.ids = [930];
exports.modules = {

/***/ 9930:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* reexport */ CarouselScreenshots)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "react-slick"
var external_react_slick_ = __webpack_require__(9080);
var external_react_slick_default = /*#__PURE__*/__webpack_require__.n(external_react_slick_);
// EXTERNAL MODULE: external "lodash"
var external_lodash_ = __webpack_require__(3804);
// EXTERNAL MODULE: ./components/Image/index.js + 1 modules
var Image = __webpack_require__(5565);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/CarouselScreenshots/CarouselScreenshots.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





/**
 * @docs https://react-slick.neostack.com/docs/api#accessibility
 */



const defaultSettings = {
  // className: 'carousel-screenshots',
  dots: true,
  infinite: true,
  autoplay: true,
  autoplaySpeed: 4000,
  slidesToScroll: 1
};
function CarouselScreenshots({
  images,
  settings,
  aspectRatio = 0.7
}) {
  const options = settings || defaultSettings;
  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/jsx_runtime_.jsx((external_react_slick_default()), _objectSpread(_objectSpread({}, options), {}, {
      children: external_lodash_.map(images, img => /*#__PURE__*/jsx_runtime_.jsx(Image/* default */.Z, {
        src: img === null || img === void 0 ? void 0 : img.url,
        aspectRatio: 0.7,
        alt: img === null || img === void 0 ? void 0 : img.alternativeText,
        title: img === null || img === void 0 ? void 0 : img.caption,
        formats: img === null || img === void 0 ? void 0 : img.formats,
        aspectRatio: aspectRatio // onClick={() => openImage(ss.url)}

      }, img === null || img === void 0 ? void 0 : img.id))
    }))
  });
}
;// CONCATENATED MODULE: ./components/CarouselScreenshots/index.js


/***/ })

};
;