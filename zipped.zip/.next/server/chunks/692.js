"use strict";
exports.id = 692;
exports.ids = [692];
exports.modules = {

/***/ 2255:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Q": () => (/* binding */ getGendersApi)
/* harmony export */ });
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9316);

async function getGendersApi() {
  try {
    const url = `${_utils_constants__WEBPACK_IMPORTED_MODULE_0__/* .BASE_PATH */ .GW}/genders`;
    const response = await fetch(url);
    const result = await response.json();
    return result;
  } catch (error) {
    console.log('getGendersApi -->>', error);
    return null;
  }
}

/***/ }),

/***/ 5692:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "O": () => (/* binding */ AppWrapper),
  "b": () => (/* binding */ useAppContext)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./api/gender.js
var gender = __webpack_require__(2255);
// EXTERNAL MODULE: ./utils/constants.js
var constants = __webpack_require__(9316);
;// CONCATENATED MODULE: ./api/categories.js

async function getCategoriesApi() {
  try {
    const url = `${constants/* BASE_PATH */.GW}/categories`;
    const response = await fetch(url);
    const result = await response.json();
    return result;
  } catch (error) {
    console.log('getCategoriesApi -->>', error);
    return null;
  }
}
// EXTERNAL MODULE: external "lodash"
var external_lodash_ = __webpack_require__(3804);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./context/StateContext.js






const AppContext = /*#__PURE__*/(0,external_react_.createContext)();
function AppWrapper({
  children
}) {
  const {
    0: categories,
    1: setCategories
  } = (0,external_react_.useState)([]);
  const {
    0: genders,
    1: setGenders
  } = (0,external_react_.useState)([]);
  const state = {
    menu: constants/* menu */.GI
  };
  (0,external_react_.useEffect)(() => {
    (async () => {
      if (external_lodash_.size(state.categories) === 0) {
        const response = await getCategoriesApi();
        setCategories(response || []);
      }
    })();
  }, []);
  (0,external_react_.useEffect)(() => {
    (async () => {
      if (external_lodash_.size(state.genders) === 0) {
        const response = await (0,gender/* getGendersApi */.Q)();
        setGenders(response || []);
      }
    })();
  }, []);
  state.categories = categories;
  state.genders = genders;
  return /*#__PURE__*/jsx_runtime_.jsx(AppContext.Provider, {
    value: state,
    children: children
  });
}
function useAppContext() {
  return (0,external_react_.useContext)(AppContext);
}

/***/ }),

/***/ 9316:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GW": () => (/* binding */ BASE_PATH),
/* harmony export */   "GI": () => (/* binding */ menu),
/* harmony export */   "wp": () => (/* binding */ defaultPrize),
/* harmony export */   "UA": () => (/* binding */ defaultDisplayCarts)
/* harmony export */ });
/* unused harmony export TOKEN */
const BASE_PATH = 'http://api-stroje.agencja-impuls.atthost24.pl';
const TOKEN = 'accessToken';
const menu = [{
  "item": "Strona główna",
  "url": "",
  "opis": "Strona główna"
}, {
  "item": "Wyszukaj",
  "url": "wyszukaj",
  "opis": "Wyszukiwarka strojów"
}, {
  "item": "Kontakt",
  "url": "kontakt",
  "opis": "Strona kontaktowa"
}];
const defaultPrize = 25;
const defaultDisplayCarts = 18;

/***/ })

};
;