"use strict";
exports.id = 346;
exports.ids = [346];
exports.modules = {

/***/ 346:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* reexport */ BreadCrumbs)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "nextjs-breadcrumbs"
var external_nextjs_breadcrumbs_ = __webpack_require__(1420);
var external_nextjs_breadcrumbs_default = /*#__PURE__*/__webpack_require__.n(external_nextjs_breadcrumbs_);
// EXTERNAL MODULE: external "@mui/styles"
var styles_ = __webpack_require__(6806);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(7949);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/BreadCrumbs/BreadCrumbs.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






function BreadCrumbs() {
  const classes = useStyles();
  return /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
    component: "section",
    className: classes.section,
    id: "floating-bread-crumbs",
    children: /*#__PURE__*/jsx_runtime_.jsx(material_.Container, {
      maxWidth: "xl",
      className: classes.container,
      children: /*#__PURE__*/jsx_runtime_.jsx((external_nextjs_breadcrumbs_default()), {
        transformLabel: title => title + ' /',
        activeItemClassName: classes.activeItem,
        inactiveItemClassName: classes.inactiveItem,
        listClassName: classes.list,
        labelsToUppercase: "true"
      })
    })
  });
}
const useStyles = (0,styles_.makeStyles)(theme => ({
  loader: {
    display: 'flex',
    justifyContent: 'center'
  },
  searchLink: {
    borderBottom: `1px solid ${theme.palette.grey[400]}`,
    '&:hover': {
      borderBottom: `1px solid ${theme.palette.grey[900]}`
    }
  },
  list: {
    display: 'flex',
    listStyleType: 'none',
    marginLeft: 0,
    paddingLeft: 0,
    justifyContent: 'flex-start',
    flexWrap: 'wrap',
    borderBottom: `1px solid ${theme.palette.grey[400]}`,
    [theme.breakpoints.up('sm')]: {
      flexDirection: 'row',
      marginTop: theme.spacing(.25),
      marginBottom: theme.spacing(1)
    },
    [theme.breakpoints.only('xs')]: {
      paddingTop: theme.spacing(0),
      paddingBottom: theme.spacing(0),
      marginTop: theme.spacing(0),
      marginBottom: theme.spacing(0)
    },
    '& > li:not(:last-child)': {
      marginRight: theme.spacing(0.25)
    },
    '&:hover': {
      borderBottom: `1px solid ${theme.palette.grey[800]}`
    }
  },
  inactiveItem: {
    '& > a': {
      color: `${theme.palette.grey[500]}`,
      fontSize: '.6rem'
    }
  },
  activeItem: {
    '& > a': {
      color: `${theme.palette.grey[900]}`,
      fontSize: '.6rem'
    }
  },
  section: {
    marginTop: theme.spacing(0.5)
  },
  container: _objectSpread({}, theme.container)
}));
;// CONCATENATED MODULE: ./components/BreadCrumbs/index.js


/***/ })

};
;