"use strict";
exports.id = 60;
exports.ids = [60];
exports.modules = {

/***/ 9639:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Nt": () => (/* binding */ getModelsApi),
/* harmony export */   "UT": () => (/* binding */ getModelByCustomProps),
/* harmony export */   "lt": () => (/* binding */ getModelByCustomPropsCount)
/* harmony export */ });
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9316);

async function getModelsApi({
  limit = '',
  sort = '',
  page = ''
}) {
  try {
    const limitItems = `_limit=${limit}`;
    const sortItems = `_sort=${sort}`;
    const startItems = `_start=${page}`;
    const url = `${_utils_constants__WEBPACK_IMPORTED_MODULE_0__/* .BASE_PATH */ .GW}/models?${limitItems}&${sortItems}&${startItems}&_publicationState=live`;
    const response = await fetch(url);
    const result = await response.json();
    return result;
  } catch (error) {
    console.log('getModelsApi -->>', error);
    return null;
  }
}
async function getModelByCustomProps(query) {
  try {
    const url = `${_utils_constants__WEBPACK_IMPORTED_MODULE_0__/* .BASE_PATH */ .GW}/models?${query}&_publicationState=live`;
    const response = await fetch(url);
    const result = await response.json();
    return result;
  } catch (error) {
    console.log('getModelByCustomProps -->>', error);
    return null;
  }
}
async function getModelByCustomPropsCount(query) {
  try {
    const url = `${_utils_constants__WEBPACK_IMPORTED_MODULE_0__/* .BASE_PATH */ .GW}/models/count?${query}&_publicationState=live`;
    const response = await fetch(url);
    const result = await response.json();
    return result;
  } catch (error) {
    console.log('getModelByCustomPropsCount -->>', error);
    return null;
  }
}

/***/ }),

/***/ 3386:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* reexport */ ElementIcon)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "@mui/styles"
var styles_ = __webpack_require__(6806);
// EXTERNAL MODULE: external "lodash"
var external_lodash_ = __webpack_require__(3804);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/CustomIcons/ElementIcon/ElementIcon.js





const elementIcons = [{
  name: 'dodatki',
  path: '/icons/001-cooking-equipment.svg'
}, {
  name: 'spodnica',
  path: '/icons/001-skirt.svg'
}, {
  name: 'sweter',
  path: '/icons/002-sweater.svg'
}, {
  name: 'bron',
  path: '/icons/002-weapons.svg'
}, {
  name: 'kostium',
  path: '/icons/003-superhero.svg'
}, {
  name: 'hełm',
  path: '/icons/003-viking-helmet.svg'
}, {
  name: 'jednoczesciowy',
  path: '/icons/004-suit.svg'
}, {
  name: 'maska',
  path: '/icons/004-theater.svg'
}, {
  name: 'buty',
  path: '/icons/005-shoes.svg'
}, {
  name: 'nakrycie-glowy',
  path: '/icons/006-pamela.svg'
}, {
  name: 'zbroja',
  path: '/icons/007-armor.svg'
}, {
  name: 'suknia',
  path: '/icons/008-dress.svg'
}, {
  name: 'koszulka',
  path: '/icons/009-shirt.svg'
}, {
  name: 't-shirt',
  path: '/icons/010-tshirt.svg'
}, {
  name: 'spodnie',
  path: '/icons/trousers.svg'
}];
function ElementIcon(props) {
  var _$find;

  const theme = (0,styles_.useTheme)();
  const src = ((_$find = external_lodash_.find(elementIcons, {
    name: props.url
  })) === null || _$find === void 0 ? void 0 : _$find.path) || '/icons/004-suit.svg';
  const width = props.width ? props.width + 'px' : '25px';
  const height = props.width ? props.width + 'px' : '25px';
  const color = (props === null || props === void 0 ? void 0 : props.color) || theme.palette.grey[700];
  const title = (props === null || props === void 0 ? void 0 : props.title) || 'kostiumy';
  return /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
    src: src,
    height: height,
    width: width,
    color: color,
    title: title
  });
}
;// CONCATENATED MODULE: ./components/CustomIcons/ElementIcon/index.js


/***/ }),

/***/ 5111:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* reexport */ FloatingMenu)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "@mui/styles"
var styles_ = __webpack_require__(6806);
// EXTERNAL MODULE: external "lodash"
var external_lodash_ = __webpack_require__(3804);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(7949);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/FloatingMenu/CategoryMenu/CategoryMenu.js







function CategoryMenu({
  menu,
  query = ''
}) {
  const classes = useStyles();
  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
      className: classes.menuList,
      component: "ul",
      className: classes.list,
      children: external_lodash_.size(menu) > 0 && external_lodash_.map(menu, item => /*#__PURE__*/jsx_runtime_.jsx(CategoryItem, {
        item: item,
        query: query
      }, item.url))
    })
  });
}

const CategoryItem = ({
  item,
  query
}) => {
  const classes = useStyles();
  return /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
    component: "li",
    className: classes.searchLink,
    children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
      href: `/kategoria/${item.url}${query ? `?q=${query}` : ''}`,
      passHref: true,
      children: /*#__PURE__*/jsx_runtime_.jsx("a", {
        children: item.title || item.kategoria
      })
    })
  });
};

const useStyles = (0,styles_.makeStyles)(theme => ({
  loader: {
    display: 'flex',
    justifyContent: 'center'
  },
  searchLink: {
    borderBottom: `1px solid ${theme.palette.grey[400]}`,
    '&:hover': {
      borderBottom: `1px solid ${theme.palette.grey[900]}`
    }
  },
  list: {
    display: 'flex',
    listStyleType: 'none',
    marginLeft: 0,
    paddingLeft: 0,
    justifyContent: 'center',
    flexWrap: 'wrap',
    [theme.breakpoints.up('sm')]: {
      justifyContent: 'flex-start',
      flexDirection: 'row',
      marginTop: theme.spacing(2),
      marginBottom: theme.spacing(1)
    },
    '& > li:not(:last-child)': {
      marginRight: theme.spacing(3),
      [theme.breakpoints.only('xs')]: {
        marginRight: theme.spacing(1)
      }
    },
    [theme.breakpoints.down('xs')]: {
      flexDirection: 'column',
      marginTop: theme.spacing(2),
      marginBottom: theme.spacing(1)
    }
  }
}));
;// CONCATENATED MODULE: ./components/FloatingMenu/CategoryMenu/index.js

// EXTERNAL MODULE: ./context/StateContext.js + 1 modules
var StateContext = __webpack_require__(5692);
;// CONCATENATED MODULE: ./components/FloatingMenu/FloatingMenu.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }










function FloatingMenu() {
  const classes = FloatingMenu_useStyles();
  const additionalMenuItems = [{
    title: 'Więcej...',
    url: 'modele'
  }];
  const {
    genders,
    categories
  } = (0,StateContext/* useAppContext */.b)();
  return /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
    component: "section",
    className: classes.section,
    id: "floating-menu",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Container, {
      maxWidth: "xl",
      className: classes.container,
      children: [/*#__PURE__*/jsx_runtime_.jsx(CategoryMenu, {
        menu: genders,
        query: 'plec'
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.Divider, {
        orientation: "vertical",
        variant: "middle",
        flexItem: true,
        className: classes.divider
      }), /*#__PURE__*/jsx_runtime_.jsx(CategoryMenu, {
        menu: categories
      })]
    })
  });
}
const FloatingMenu_useStyles = (0,styles_.makeStyles)(theme => ({
  loader: {
    display: 'flex',
    justifyContent: 'center'
  },
  section: {
    background: theme.palette.grey[100],
    marginTop: theme.spacing(1.25)
  },
  container: _objectSpread({}, theme.container),
  divider: {
    marginLeft: theme.spacing(1),
    marginRight: theme.spacing(1),
    [theme.breakpoints.down('sm')]: {
      display: 'none'
    }
  }
}));
;// CONCATENATED MODULE: ./components/FloatingMenu/index.js


/***/ }),

/***/ 5565:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* reexport */ ImageCustom)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "material-ui-image"
var external_material_ui_image_ = __webpack_require__(7378);
var external_material_ui_image_default = /*#__PURE__*/__webpack_require__.n(external_material_ui_image_);
// EXTERNAL MODULE: external "@mui/styles"
var styles_ = __webpack_require__(6806);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(7949);
// EXTERNAL MODULE: external "lodash"
var external_lodash_ = __webpack_require__(3804);
// EXTERNAL MODULE: ./utils/constants.js
var constants = __webpack_require__(9316);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/Image/Image.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }








function ImageCustom(props) {
  const theme = (0,styles_.useTheme)();
  let size = props.src;
  const isKomputer = (0,material_.useMediaQuery)(theme.breakpoints.up('lg'));
  const isTablet = (0,material_.useMediaQuery)(theme.breakpoints.only('md'));
  const isMobile = (0,material_.useMediaQuery)(theme.breakpoints.down('sm'));

  if (external_lodash_.size(props.formats) > 0) {
    var _props$formats, _props$formats$large, _props$formats2, _props$formats2$mediu, _props$formats3, _props$formats3$small;

    if (isKomputer) size = ((_props$formats = props.formats) === null || _props$formats === void 0 ? void 0 : (_props$formats$large = _props$formats.large) === null || _props$formats$large === void 0 ? void 0 : _props$formats$large.url) || size;
    if (isTablet) size = ((_props$formats2 = props.formats) === null || _props$formats2 === void 0 ? void 0 : (_props$formats2$mediu = _props$formats2.medium) === null || _props$formats2$mediu === void 0 ? void 0 : _props$formats2$mediu.url) || size;
    if (isMobile) size = ((_props$formats3 = props.formats) === null || _props$formats3 === void 0 ? void 0 : (_props$formats3$small = _props$formats3.small) === null || _props$formats3$small === void 0 ? void 0 : _props$formats3$small.url) || size;
  }

  return /*#__PURE__*/jsx_runtime_.jsx((external_material_ui_image_default()), _objectSpread(_objectSpread({}, props), {}, {
    src: `${constants/* BASE_PATH */.GW}${size}`
  }));
}
;// CONCATENATED MODULE: ./components/Image/index.js


/***/ }),

/***/ 9782:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* reexport */ ListModels)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(7949);
// EXTERNAL MODULE: external "@mui/styles"
var styles_ = __webpack_require__(6806);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "clsx"
var external_clsx_ = __webpack_require__(3536);
var external_clsx_default = /*#__PURE__*/__webpack_require__.n(external_clsx_);
// EXTERNAL MODULE: external "@mui/material/Card"
var Card_ = __webpack_require__(4501);
var Card_default = /*#__PURE__*/__webpack_require__.n(Card_);
// EXTERNAL MODULE: external "@mui/material/CardActions"
var CardActions_ = __webpack_require__(8136);
var CardActions_default = /*#__PURE__*/__webpack_require__.n(CardActions_);
// EXTERNAL MODULE: external "@mui/material/Collapse"
var Collapse_ = __webpack_require__(4929);
var Collapse_default = /*#__PURE__*/__webpack_require__.n(Collapse_);
// EXTERNAL MODULE: external "@mui/material/IconButton"
var IconButton_ = __webpack_require__(2219);
var IconButton_default = /*#__PURE__*/__webpack_require__.n(IconButton_);
// EXTERNAL MODULE: external "@mui/icons-material/ExpandMore"
var ExpandMore_ = __webpack_require__(1193);
var ExpandMore_default = /*#__PURE__*/__webpack_require__.n(ExpandMore_);
// EXTERNAL MODULE: ./components/Image/index.js + 1 modules
var Image = __webpack_require__(5565);
// EXTERNAL MODULE: external "lodash"
var external_lodash_ = __webpack_require__(3804);
// EXTERNAL MODULE: external "@mui/material/CardHeader"
var CardHeader_ = __webpack_require__(4451);
var CardHeader_default = /*#__PURE__*/__webpack_require__.n(CardHeader_);
// EXTERNAL MODULE: external "@mui/material/Avatar"
var Avatar_ = __webpack_require__(7541);
var Avatar_default = /*#__PURE__*/__webpack_require__.n(Avatar_);
// EXTERNAL MODULE: external "@mui/material/colors"
var colors_ = __webpack_require__(517);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/ListModelsCards/ModelCard/CustomCardHeader/CustomCardHeader.js





function CustomCardHeader({
  model
}) {
  const classes = useStyles();
  return /*#__PURE__*/jsx_runtime_.jsx((CardHeader_default()), {
    avatar: /*#__PURE__*/jsx_runtime_.jsx((Avatar_default()), {
      "aria-label": "P\u0142e\u0107",
      className: classes.avatar,
      title: model.plec.title,
      children: model.plec.title[0]
    }),
    title: model.tytul
  });
}
;
const useStyles = (0,styles_.makeStyles)(theme => ({
  avatar: {
    backgroundColor: theme.palette.common.secondary.main
  }
}));
;// CONCATENATED MODULE: ./components/ListModelsCards/ModelCard/CustomCardHeader/index.js

;// CONCATENATED MODULE: ./components/SizeList/SizeList.js



function SizeList({
  model
}) {
  const classes = SizeList_useStyles();
  return /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
    className: classes.sizeList,
    children: _.map(model.sizes, s => /*#__PURE__*/jsx_runtime_.jsx(HtmlTooltip, {
      title: /*#__PURE__*/jsx_runtime_.jsx("em", {
        children: s.opis
      }),
      children: /*#__PURE__*/jsx_runtime_.jsx("span", {
        className: classes.size,
        children: s.rozmiar
      }, s.url)
    }, s.url))
  });
}
;
const HtmlTooltip = (0,styles_.withStyles)(theme => ({
  tooltip: {
    backgroundColor: '#f5f5f9',
    color: 'rgba(0, 0, 0, 0.87)',
    maxWidth: 220,
    fontSize: theme.typography.pxToRem(12),
    border: '1px solid #dadde9'
  }
}))(material_.Tooltip);
const SizeList_useStyles = (0,styles_.makeStyles)(theme => ({
  size: {
    border: `1px solid ${theme.palette.grey[500]}`,
    padding: theme.spacing(1)
  },
  sizeList: {
    marginTop: theme.spacing(1),
    '& > :not(:last-child)': {
      marginRight: '1px'
    }
  }
}));
;// CONCATENATED MODULE: ./components/SizeList/index.js

// EXTERNAL MODULE: ./components/CustomIcons/ElementIcon/index.js + 1 modules
var ElementIcon = __webpack_require__(3386);
;// CONCATENATED MODULE: ./components/IconTypeList/IconTypeList.js





function IconTypeList({
  model
}) {
  const classes = IconTypeList_useStyles();
  return /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
    className: classes.icons,
    children: external_lodash_.map(model.parts, part => /*#__PURE__*/jsx_runtime_.jsx(ElementIcon/* default */.Z, {
      title: part.tytul,
      url: part.url
    }, part.url))
  });
}
;
const IconTypeList_useStyles = (0,styles_.makeStyles)(theme => ({
  icons: {
    display: 'flex',
    justifyContent: 'flex-end'
  }
}));
;// CONCATENATED MODULE: ./components/IconTypeList/index.js

;// CONCATENATED MODULE: ./components/ListModelsCards/ModelCard/CustomCardContent/CustomCardContent.js








function CustomCardContent({
  model
}) {
  const classes = CustomCardContent_useStyles();
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.CardContent, {
    className: classes.cardContent,
    children: [_.size(model.opis) > 0 && /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
      children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
        className: classes.opisContent,
        children: model.opis
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.Divider, {})]
    }), _.size(model.parts) > 0 && /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
        className: classes.container,
        children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
          className: classes.opisContent,
          children: "Elementy stroju:"
        }), /*#__PURE__*/jsx_runtime_.jsx(IconTypeList, {
          model: model
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.Divider, {})]
    }), _.size(model.sizes) > 0 && /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
      className: classes.container,
      children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
        className: classes.opisContent,
        children: "Dost\u0119pne rozmiary:"
      }), /*#__PURE__*/jsx_runtime_.jsx(SizeList, {
        model: model
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
      className: classes.container,
      children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
        className: classes.opisContent,
        children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: `/${model.url}`,
          passHref: true,
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            className: classes.link,
            children: "Czytaj wi\u0119cej..."
          })
        })
      })
    })]
  });
}
;
const CustomCardContent_useStyles = (0,styles_.makeStyles)(theme => ({
  cardContent: {
    '& > :not(:last-child)': {
      marginBottom: theme.spacing(1)
    }
  },
  opisContent: {
    color: theme.palette.grey[600],
    fontSize: '.9rem'
  },
  container: {
    display: 'flex',
    justifyContent: 'space-between'
  },
  link: {
    textDecoration: 'underline',
    color: theme.palette.common.secondary.main
  }
}));
;// CONCATENATED MODULE: ./components/ListModelsCards/ModelCard/CustomCardContent/index.js

;// CONCATENATED MODULE: ./components/ListModelsCards/ModelCard/ModelCard.js
















function ModelCard({
  model
}) {
  const {
    0: expanded,
    1: setExpanded
  } = (0,external_react_.useState)(false);
  const classes = ModelCard_useStyles();
  const hasPhotos = external_lodash_.size(model.zdjecia) > 0;

  const handleExpandClick = () => {
    setExpanded(!expanded);
  };

  return /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
    component: "li",
    item: true,
    xs: 12,
    sm: 6,
    md: 4,
    lg: 2,
    className: classes.li,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)((Card_default()), {
      className: classes.root,
      children: [/*#__PURE__*/jsx_runtime_.jsx(CustomCardHeader, {
        model: model
      }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
        href: `/${model.url}`,
        passHref: true,
        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
          children: /*#__PURE__*/jsx_runtime_.jsx(Image/* default */.Z, {
            src: hasPhotos ? model.zdjecia[0].url : '',
            aspectRatio: 0.7,
            alt: hasPhotos ? model.zdjecia[0].alternativeText : '',
            title: hasPhotos ? model.zdjecia[0].caption : '',
            formats: hasPhotos ? model.zdjecia[0].formats : ''
          })
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(CustomActions, {
        handleExpandClick: handleExpandClick,
        expanded: expanded
      }), /*#__PURE__*/jsx_runtime_.jsx(CustomCollapse, {
        expanded: expanded,
        children: /*#__PURE__*/jsx_runtime_.jsx(CustomCardContent, {
          model: model
        })
      })]
    })
  });
}

const CustomCollapse = ({
  expanded,
  children
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx((Collapse_default()), {
    in: expanded,
    timeout: "auto",
    unmountOnExit: true,
    children: external_lodash_.size(children) > 0 && children
  });
};

const CustomActions = ({
  handleExpandClick,
  expanded
}) => {
  const classes = ModelCard_useStyles();
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)((CardActions_default()), {
    disableSpacing: true,
    className: classes.actions,
    children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
      variant: "body2",
      color: "textSecondary",
      component: "p",
      children: "Rozwi\u0144 sczeg\xF3\u0142y"
    }), /*#__PURE__*/jsx_runtime_.jsx((IconButton_default()), {
      className: external_clsx_default()(classes.expand, {
        [classes.expandOpen]: expanded
      }),
      onClick: handleExpandClick,
      "aria-expanded": expanded,
      "aria-label": "show more",
      children: /*#__PURE__*/jsx_runtime_.jsx((ExpandMore_default()), {})
    })]
  });
};

const ModelCard_useStyles = (0,styles_.makeStyles)(theme => ({
  root: {
    maxWidth: 'auto',
    display: 'flex',
    flexDirection: 'column'
  },
  li: {
    [theme.breakpoints.down('sm')]: {
      paddingLeft: '0 !important'
    }
  },
  actions: {
    marginTop: 'auto'
  },
  expand: {
    transform: 'rotate(0deg)',
    marginLeft: 'auto',
    transition: theme.transitions.create('transform', {
      duration: theme.transitions.duration.shortest
    })
  },
  expandOpen: {
    transform: 'rotate(180deg)'
  }
}));
;// CONCATENATED MODULE: ./components/ListModelsCards/ListModelCards.js






function ListModels({
  models
}) {
  const classes = ListModelCards_useStyles();
  return /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
    container: true,
    className: classes.list,
    spacing: 2,
    component: "ul",
    className: classes.list,
    children: external_lodash_.size(models) > 0 && external_lodash_.map(models, model => /*#__PURE__*/jsx_runtime_.jsx(ModelCard, {
      model: model
    }, model.tytul))
  });
}
const ListModelCards_useStyles = (0,styles_.makeStyles)(theme => ({
  list: {
    display: 'flex',
    listStyleType: 'none',
    justifyContent: 'center',
    margin: 'auto',
    padding: 0,
    flexGrow: 1,
    [theme.breakpoints.up('sm')]: {
      flexDirection: 'row',
      marginTop: '3rem'
    }
  }
}));
;// CONCATENATED MODULE: ./components/ListModelsCards/index.js


/***/ })

};
;