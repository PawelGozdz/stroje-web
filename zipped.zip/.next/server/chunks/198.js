"use strict";
exports.id = 198;
exports.ids = [198];
exports.modules = {

/***/ 446:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* reexport */ EmptyBar)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "@mui/styles"
var styles_ = __webpack_require__(6806);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(7949);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/EmptyBar/EmptyBar.js




function EmptyBar({
  children
}) {
  const classes = useStyles();
  return /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
    className: classes.space,
    children: children
  });
}
const useStyles = (0,styles_.makeStyles)(theme => ({
  space: {
    minHeight: '6rem'
  }
}));
;// CONCATENATED MODULE: ./components/EmptyBar/index.js


/***/ }),

/***/ 9863:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "br": () => (/* binding */ getStartItem),
  "ut": () => (/* binding */ limitPerPage)
});

// UNUSED EXPORTS: authFetch

// EXTERNAL MODULE: ./utils/constants.js
var constants = __webpack_require__(9316);
// EXTERNAL MODULE: external "jwt-decode"
var external_jwt_decode_ = __webpack_require__(6420);
;// CONCATENATED MODULE: ./api/token.js


function setToken(token) {
  localStorage.setItem(TOKEN, token);
}
function token_getToken() {
  return localStorage.getItem(TOKEN);
}
function removeToken() {
  localStorage.removeItem(TOKEN);
}
function token_hasExpiredToken(token) {
  const tokenDecode = jwtDecode(token);
  const expireDate = tokenDecode.exp * 1000;
  const currentDate = new Date().getTime();

  if (currentDate > expireDate) {
    return true;
  }

  return false;
}
;// CONCATENATED MODULE: ./utils/fetch.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



async function authFetch(url, params, logout) {
  const token = getToken();

  if (!token) {
    // usuario no logeador
    logout();
  } else {
    if (hasExpiredToken(token)) {
      // Token caducado
      logout();
    } else {
      const paramsTemp = _objectSpread(_objectSpread({}, params), {}, {
        headers: _objectSpread(_objectSpread({}, params === null || params === void 0 ? void 0 : params.headers), {}, {
          Authorization: `Bearer ${token}`
        })
      });

      try {
        const response = await fetch(url, paramsTemp);
        const result = await response.json();
        return result;
      } catch (error) {
        return error;
      }
    }
  }
}
const limitPerPage = query => {
  const currentLimit = parseInt(query.limit) || 6;
  if (!query.limit || Math.abs(currentLimit) > 36) return constants/* defaultDisplayCarts */.UA;else return currentLimit;
};
const getStartItem = query => {
  const currentPage = parseInt(query.page) || 0;
  const limit = limitPerPage(query);
  if (!query.page || currentPage === 1) return 0;else return currentPage * limit - limit;
};

/***/ })

};
;