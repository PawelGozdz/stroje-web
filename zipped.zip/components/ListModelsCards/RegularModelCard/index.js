export { default } from './RegularModelCard';
