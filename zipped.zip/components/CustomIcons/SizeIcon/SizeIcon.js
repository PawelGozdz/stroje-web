import React from 'react'

export default function SizeIcon() {
  return (
    <div>
      Size Icon
    </div>
  )
}
