export { default } from './SizeIcon';
