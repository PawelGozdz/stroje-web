import BasicLayout from '../layouts/BasicLayout';

export default function Wyszukaj() {

  return (
    <BasicLayout>
      Wyszukaj...
    </BasicLayout>
  )
}


