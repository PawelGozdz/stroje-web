export const BASE_PATH = 'http://api-stroje.agencja-impuls.atthost24.pl';
export const TOKEN = 'accessToken';

export const menu = [{
  "item": "Strona główna", "url": "", "opis": "Strona główna"
}, {
  "item": "Wyszukaj", "url": "wyszukaj", "opis": "Wyszukiwarka strojów",
}, {
  "item": "Kontakt", "url": "kontakt", "opis": "Strona kontaktowa",
}
]

export const defaultPrize = 25;
export const defaultDisplayCarts = 18;